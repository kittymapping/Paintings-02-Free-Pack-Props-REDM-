Kitty Paintings 02 - Free Pack

Thank you for your download!

This package contains 8 custom made paintings. 

Prop names:
k_pa_f_painting_01
k_pa_f_painting_02
k_pa_f_painting_03
k_pa_f_painting_04
k_pa_f_painting_05
k_pa_f_painting_06
k_pa_f_painting_07
k_pa_f_painting_08

Installation for the props: 
	      1. Unzip the file and drag into your resources.
	      2. Ensure the resource.

Each of the props can be placed with Spooner.
1. Open Spooner
2. Go to Objects
3. Type the correct name of the prop
4. Go to "Spawn by name"
5. Press "E" on your keyboard

